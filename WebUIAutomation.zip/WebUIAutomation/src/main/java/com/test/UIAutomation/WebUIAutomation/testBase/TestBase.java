package com.test.UIAutomation.WebUIAutomation.testBase;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

import com.sun.jna.platform.FileUtils;
import com.test.UIAutomation.WebUIAutomation.uiActions.HomePage;

public class TestBase {
	
	public static final Logger log = Logger.getLogger(TestBase.class.getName());
	HomePage homePage;
	public WebDriver driver;
	String url = "https://www.flipkart.com/";
	String browser = "chrome";
	
	public void init(){
		selectBrowser(browser);
		getURL(url);
		String log4jConfPath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
	}
	
	public void selectBrowser(String browser){
		if(browser.equalsIgnoreCase("chrome")){
			
			System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver.exe");
			log.info("creating the object of "+browser);
			driver = new ChromeDriver();
		}		
	}
	
	public void getURL(String url){
		driver.manage().window().maximize();
		log.info("navigating to "+url);
		driver.get(url);
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}
	
	public void getScreenShot(String name){
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_h_mm_ss");
		
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath()+"src/main/java/com/test/UIAutomation/WebUIAutomation/screenshot";
			File destFile = new File((String) reportDirectory + name + "_"+formater.format(calendar.getTime()) +".png");
			org.apache.commons.io.FileUtils.copyFile(srcFile, destFile);
			Reporter.log("<a href='"+destFile.getAbsolutePath()+"'><img src='"+destFile.getAbsolutePath()+"' height='100' width='100'/></a>");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
