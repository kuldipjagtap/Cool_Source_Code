package com.test.UIAutomation.WebUIAutomation.uiActions;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	public static final Logger log = Logger.getLogger(HomePage.class.getName());
	WebDriver driver;
	
	@FindBy(xpath="//*[text()='Log In']")
	WebElement linkLogin;
	
	@FindBy(xpath="//input[@class='_2zrpKA']")
	WebElement loginUsername;
	
	@FindBy(xpath="//input[@class='_2zrpKA _3v41xv']")
	WebElement loginPassword;
	
	@FindBy(xpath="//*[@class='_2AkmmA _1LctnI _7UHT_c']")
	WebElement buttonLogin;
	
	@FindBy(xpath="//*[text()='Your username or password is not correct']")
	WebElement authenticationFailed;
	
	@FindBy(xpath="//button[@class='_2AkmmA _29YdH8']")
	WebElement defaultLoginWindow;
	
	@FindBy(xpath="//*[text()='My Account']")
	WebElement myAccountTextOnLogin;
	
	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void loginToApplication(String emailAddress, String password){
		
		if(defaultLoginWindow.isDisplayed()){
			defaultLoginWindow.click();
		}
		linkLogin.click();
		log.info("clicked on sign in and object is"+linkLogin.toString());
		loginUsername.sendKeys(emailAddress);
		log.info("entered user name and object is"+loginUsername.toString());
		loginPassword.sendKeys(password);
		log.info("entered password and object is"+loginPassword.toString());
		buttonLogin.click();
		log.info("clicked on login button and object is"+buttonLogin.toString());
	}
	
	public String getInvalidLoginMessage(){
		return authenticationFailed.getText();
	}
	
	public boolean getSuccessfulLogin(){
		try{
			myAccountTextOnLogin.isDisplayed();
			return true;
		}catch(Exception e){
			log.info("Login is failed");
			return false;
		}
	}
	
	public void clickOnNavigationMenu(String menuName){
		driver.findElement(By.xpath("//*[@title='"+menuName+"']"));
		log.info("clicked on:"+menuName+"navigation menu");
	}
	
	public void clickOnProductInMensSection(String productName){
		driver.findElement(By.xpath("//*[@title='"+productName+"']")).click();
	}
}
