package com.test.UIAutomation.WebUIAutomation.home;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.test.UIAutomation.WebUIAutomation.testBase.TestBase;
import com.test.UIAutomation.WebUIAutomation.uiActions.HomePage;

public class TC001_VerifyLoginWithInvalidCredentials extends TestBase{
	
	public static final Logger log = Logger.getLogger(TC001_VerifyLoginWithInvalidCredentials.class.getName());
	
	HomePage homePage;
	@BeforeTest
	public void setUp(){
	init();
	}
	@Test
	public void verifyLoginWithInvalidCredentials(){
		log.info("================= Starting verifyLoginWithInvalidCredentials================");
		homePage = new HomePage(driver);
		homePage.loginToApplication("kjagtap964@gmail.com", "password123");
		Assert.assertEquals(homePage.getInvalidLoginMessage(), "Your username or password is not correct");
		log.info("================= Finished verifyLoginWithInvalidCredentials================");
	}
	@AfterClass
	public void endTest(){
		driver.close();
	}

}
