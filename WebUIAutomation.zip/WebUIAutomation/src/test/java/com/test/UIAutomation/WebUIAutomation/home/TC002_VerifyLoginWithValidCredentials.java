package com.test.UIAutomation.WebUIAutomation.home;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.test.UIAutomation.WebUIAutomation.testBase.TestBase;
import com.test.UIAutomation.WebUIAutomation.uiActions.HomePage;

public class TC002_VerifyLoginWithValidCredentials extends TestBase{
	
	HomePage homePage;
	@BeforeClass
	public void setUp(){
		init();
	}
	
	@Test
	public void verifyLoginWithValidCredentials(){
		homePage = new HomePage(driver);
		homePage.loginToApplication("9960347993", "Kuldip@192");
		getScreenShot("Test");
		homePage.getSuccessfulLogin();
		Assert.assertEquals(homePage.getSuccessfulLogin(), true);
		homePage.clickOnNavigationMenu("Men");
		homePage.clickOnProductInMensSection("Shirts");
		
		
	}

}
